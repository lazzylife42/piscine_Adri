	#include <stdio.h>
	#include <stdlib.h>

 int main(int argc, char *argv[]) {
	if (argc !=4) {
	   fprintf(stderr, "Usage: %s <nombre1> <operation> <nombre2>/n", argv[0]);
	   return 1; }

 int nombre1 = atoi(argv[1]);
 char operation = argv[2][0];
 int nombre2 = atoi(argv[3]);

 int resultat;

 switch (operation) {
	case '+':
 	   resultat = nombre1 + nombre2;
           break;
	case '-':
	   resultat = nombre1 - nombre2;
	   break;
	case '*':
           resultat = nombre1 * nombre2;
	   break;
	case '/':

	   if (nombre2 == 0) {
	   fprintf(stderr, "Erreur: Division par zero.\n");
	   return 1;
	}
	 resultat = nombre1 / nombre2;
	 break;
    default: 
	 fprintf(stderr, "Erreur: Operation non reconnue.\n");
	   return 1;
	}

 char buffer[20];
 snprintf(buffer, sizeof(buffer), "%d", resultat);
 puts(buffer);
	   
	   return 0;

	}   
 
