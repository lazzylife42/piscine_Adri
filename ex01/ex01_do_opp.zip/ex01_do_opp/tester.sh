#!/bin/bash

./do_opp 5 + 3
./do_opp 10 - 5
./do_opp 6 '*' 4
./do_opp 10 / 2
./do_opp 8 / 0
./do_opp 5 % 2

