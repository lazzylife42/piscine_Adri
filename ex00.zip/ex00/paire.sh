	#!/bin/bash

	
	i=0
	while read -r line; do
	
	if ((i % 2 == 0)); then
	echo "$line"
	fi
	((i++))
done
